import "../styles/footer.css";

const Footer = () => {
    return (
        <footer>
            Footer
        </footer>
    )
};

export default Footer;