import "../styles/nav.css";
import { MdOutlineMenuBook } from "react-icons/md";
import { IoMdHome } from "react-icons/io";
import { FaEnvelope } from "react-icons/fa6";

const Nav = () => {
    return (
        <nav>
            <a href={"#"}>Strona Główna <IoMdHome className="navicon"/></a>
            <a href={"#"}>Menu <MdOutlineMenuBook className="navicon" /></a>
            <a href={"#"}>Kontakt <FaEnvelope className="navicon" /></a>
        </nav>
    )
};

export default Nav;