import "../styles/auth.css";
import {useState} from "react"

const Auth = () => {
    const [isRegistered, setIsRegistered] = useState(true);
    if (isRegistered) {
        return (
            <form className="auth" id="login">
                <h1>Zaloguj się</h1>
                <input name="email" placeholder="Email" type="email" required />
                <input name="password" placeholder="Hasło" type="password" required />
                <button type="submit">Zaloguj</button>
                <label>
                    <input type="checkbox" name="remember" /> Zapamiętaj mnie
                </label>
                <p>Zapomniałeś <a href="#">hasła?</a></p>
                <p>Nie masz jeszcze konta? <a href="#" onClick={() => setIsRegistered(!isRegistered)}>Stwórz je!</a></p>
            </form>
        )
    } else {
        return (
            <form className="auth" id="register">
                <h1>Stwórz konto</h1>
                <input name="email" placeholder="Email" type="email" required />
                <input name="password" placeholder="Hasło" type="password" required />
                <input name="password" placeholder="Potwierdź hasło" type="password" required />
                <button type="submit">Stwórz konto</button>
                <p>Masz już konto? <a href="#" onClick={() => setIsRegistered(!isRegistered)}>Zaloguj się!</a></p>
            </form>
        )
    }
}
    
export default Auth;