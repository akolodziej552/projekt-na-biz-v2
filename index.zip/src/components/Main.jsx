import Auth from "./Auth";
const Main = ({ active }) => {
    if (active == "Auth") {
        return (
            <main>
                <Auth />
            </main>
            )
    } else if (active == "Contact") {
        return (
            <address>
                Kontakt
            </address>
        )
    } else if (active == "Cart") {
        <article>
            cart
        </article>
    }
}
export default Main;