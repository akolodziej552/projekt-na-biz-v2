import Header from "./Header";
import Nav from "./Nav";
import Footer from "./Footer";
import Main from "./Main";
import "../styles/app.css";
import { useState } from "react";

const App = () => {
    const [activePage, setActivePage] = useState("Auth")
    return (
        <div className="app">
            <Header /> 
            <Nav />
            <Main active={activePage}/>
            <Footer />
        </div>
    )
};
export default App;