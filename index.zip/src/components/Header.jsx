import "../styles/header.css";
import logo from "../assets/zsllogo.ico";
import { FaPhone } from "react-icons/fa6";
import { FaShoppingCart } from "react-icons/fa";
import { MdAccountCircle } from "react-icons/md";

const Header = () => {
    const homePage = () => {
        window.location.href = "67";
    }
    const copyTel = () => {
        navigator.clipboard.writeText("730379195");
        alert("Numer telefonu został skopiowany!");
    }
    return (
        <header>
            <address onClick={copyTel}>
                <p className="telnum"><FaPhone className="telnum" /> 730 379 195</p>
            </address>
            <img src={logo} onClick={homePage}/>
            <div className="shopacc">
                <a href={"#"}><FaShoppingCart /></a>
                <a href={"#"}><MdAccountCircle /></a>
            </div>
        </header>
    )
}

export default Header;